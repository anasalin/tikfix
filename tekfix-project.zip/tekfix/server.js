const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'orders.json');

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Initialize DB file
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify([]));
}

function readOrders() {
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}

function saveOrders(orders) {
  fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));
}

// ─── ROUTES ───────────────────────────────────────────────

// POST /api/orders — إنشاء طلب جديد
app.post('/api/orders', (req, res) => {
  const { name, phone, device, time, problem, lat, lng, address } = req.body;

  if (!name || !phone || !device) {
    return res.status(400).json({ error: 'الاسم والجوال ونوع الجهاز مطلوبة' });
  }

  const orders = readOrders();
  const newOrder = {
    id: Date.now(),
    name,
    phone,
    device,
    time: time || '',
    problem: problem || '',
    lat: lat || null,
    lng: lng || null,
    address: address || '',
    status: 'جديد',
    createdAt: new Date().toISOString()
  };

  orders.unshift(newOrder);
  saveOrders(orders);

  console.log(`✅ طلب جديد من ${name} — ${device}`);
  res.status(201).json({ success: true, order: newOrder });
});

// GET /api/orders — جلب كل الطلبات (للوحة التحكم)
app.get('/api/orders', (req, res) => {
  const secret = req.headers['x-admin-secret'];
  if (secret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: 'غير مصرح' });
  }
  res.json(readOrders());
});

// PATCH /api/orders/:id — تحديث حالة الطلب
app.patch('/api/orders/:id', (req, res) => {
  const secret = req.headers['x-admin-secret'];
  if (secret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: 'غير مصرح' });
  }

  const orders = readOrders();
  const idx = orders.findIndex(o => o.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'الطلب غير موجود' });

  orders[idx].status = req.body.status;
  saveOrders(orders);
  res.json(orders[idx]);
});

// DELETE /api/orders/:id
app.delete('/api/orders/:id', (req, res) => {
  const secret = req.headers['x-admin-secret'];
  if (secret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: 'غير مصرح' });
  }

  let orders = readOrders();
  orders = orders.filter(o => o.id !== parseInt(req.params.id));
  saveOrders(orders);
  res.json({ success: true });
});

// Catch-all: serve index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 تكفيكس يعمل على http://localhost:${PORT}`);
});

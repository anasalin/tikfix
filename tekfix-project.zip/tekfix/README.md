# تكفيكس 🔧
### موقع صيانة أجهزة مع توصيل من الباب وإليه

---

## 🗂️ هيكل المشروع
```
tekfix/
├── server.js          ← السيرفر الرئيسي (API)
├── package.json
├── .env               ← إعدادات سرية (لا ترفعها على GitHub)
├── orders.json        ← قاعدة البيانات (تُنشأ تلقائياً)
└── public/
    ├── index.html     ← الموقع الرئيسي للزبائن
    └── admin.html     ← لوحة التحكم
```

---

## ⚙️ الإعداد المحلي
```bash
npm install
node server.js
```
افتح المتصفح على: http://localhost:3000

---

## 🔐 لوحة التحكم
رابطها: `/admin.html`
كلمة المرور الافتراضية: `tekfix2025`
غيّرها في ملف `.env` → `ADMIN_SECRET=كلمتك_الجديدة`

---

## 🚀 الرفع على Railway (مجاني)

1. **ارفع الكود على GitHub:**
   - روح على github.com → New Repository
   - ارفع كل الملفات عدا `.env` و `node_modules`

2. **افتح Railway:**
   - روح على railway.app
   - سجّل بحساب GitHub
   - اضغط "New Project" → "Deploy from GitHub repo"
   - اختر الـ repo

3. **أضف المتغيرات:**
   - في Railway: Variables → Add Variable
   - `ADMIN_SECRET` = كلمة مرور تختارها
   - `PORT` = 3000

4. **انسخ الرابط** اللي بيعطيك إياه Railway وابعته للزبائن!

---

## 📱 API Endpoints

| Method | Endpoint | الوظيفة |
|--------|----------|---------|
| POST | /api/orders | إنشاء طلب جديد |
| GET | /api/orders | جلب كل الطلبات (admin) |
| PATCH | /api/orders/:id | تحديث حالة طلب (admin) |
| DELETE | /api/orders/:id | حذف طلب (admin) |

---

## ✏️ تخصيص
- غيّر رقم الواتساب في `public/index.html` → ابحث عن `970599000000`
- غيّر الأسعار في قسم الخدمات
- غيّر الاسم من `تكفيكس` للاسم اللي تبيه
